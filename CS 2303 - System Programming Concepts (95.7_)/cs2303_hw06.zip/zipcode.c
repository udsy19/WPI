#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <readline/readline.h>
#include <readline/history.h>
#include <forward_list>
#include "zipfed.hpp"
#include <iostream>
#include <vector>
#define SZ_FILENAME (129)
#define MAX (10000)


ssize_t readln_cs2303(char **lineptr, size_t *n, FILE *stream)
{
    ssize_t bytes_read = -1;
    const int delim = '\n';

    if (stream == NULL)
        return (ssize_t) -1;

    bytes_read = getdelim(lineptr, n, delim, stream);

    for (int i = bytes_read - 1; i >= 0; i--)
    {
        if ((*lineptr)[i] == '\n')
            (*lineptr)[i] = '\0';
    }

    return bytes_read;
}

bool comparator(Zipfed* ptrZip1, Zipfed* ptrZip2)
{
    return ptrZip1->getCity().compare(ptrZip2->getCity()) < 0;
}

int main(int argc, char* argv[])
{

    char infile[SZ_FILENAME]; // Path/name of inputfile
    FILE* fdIn;

    ssize_t chars_read;        // number of chars read for line of input
    char* inbuf = NULL;        // input file has 1 record per line to temp
    size_t sz_inbuf = 0;       // current size of the input record

    std::forward_list<Zipfed*> llist; //singly linked list of pointers to Zipfed instances

    /* Open input and output files specified on command line
     * Common sense error checking on cmd line parameters
     */
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s input_file output_file\n", argv[0]);
        return -1;
    }

    strncpy(infile, argv[1], SZ_FILENAME - 1);

    /* Open input and output files - return error on failure
     * input for reading. output for writing
     */
    fdIn = fopen(infile, "r");
    if (fdIn == NULL)
    {
        fprintf(stderr, "cannot open %s for input - exiting\n", infile);
        return -2;
    }

    std::vector<std::string> query;

    char* temp = (char*)calloc(1, MAX);

    printf("Enter city names:\n");

    size_t counter;
    for (counter = 0; (temp = readline("_ ")) != NULL; counter++)
    {
        query.push_back(temp);
    }

    printf("\n");

   while ((chars_read = readln_cs2303(&inbuf, &sz_inbuf, fdIn)) != EOF)
	{
		if (chars_read == 0)
			continue;

		Zipfed *ptrZipfed = new Zipfed();
		if(ptrZipfed->parse_cs2303(inbuf) != 0)
		{
			fprintf (stderr, "faiiled to parse\n");
			fclose (fdIn);
			return -4;
		}

		if (ptrZipfed->is_from(query))
			llist.push_front(ptrZipfed);
	}

	llist.sort (comparator);

	for(std::forward_list<Zipfed *>::iterator it = llist.begin(); it != llist.end(); it++)
	{
		Zipfed * ptrTmpZipfed = *it;
		ptrTmpZipfed->print();
	}

	while (!llist.empty()) 
		llist.pop_front();

	free (temp);

	return 0;
}
