#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <forward_list>
#include "zipfed.hpp"

#define SZ_FILENAME (129)

ssize_t readln_fed(char **lineptr, size_t *n, FILE *stream)
{
  ssize_t bytes_read = -1; // -1 will signify error reading line
  const int delim = '\n';  // each line terminated with \r\n

  // Verify the file is open
  if (stream == NULL)
  {
    return (ssize_t)-1;
  }

  bytes_read = getdelim(lineptr, n, delim, stream);

  int i = bytes_read - 1;
  while (i >= 0)
  {
    if (((*lineptr)[i] == '\n') || ((*lineptr)[i] == '\r'))
    {
      (*lineptr)[i] = '\0';
    }
    i--;
  }

  return bytes_read;
}

int main(int argc, char *argv[])
{
  char infile[SZ_FILENAME];  // Path/name of input file
  char outfile[SZ_FILENAME]; // Path/name of output file
  FILE *fdIn;
  FILE *fdOut;

  ssize_t chars_read;  // number of chars read for line of input
  char *inbuf = NULL;  // input file has 1 record per line to buffer
  size_t sz_inbuf = 0; // current size of the input record

  std::forward_list<Zipfed *> llist; // singly linked list of pointers to Zipfed instances

  if (argc != 3)
  {
    fprintf(stderr, "usage: %s input_file output_file\n", argv[0]);
    return -1;
  }

  strncpy(infile, argv[1], SZ_FILENAME - 1);
  strncpy(outfile, argv[2], SZ_FILENAME - 1);

  fdIn = fopen(infile, "r");
  if (fdIn == NULL)
  {
    fprintf(stderr, "cannot open %s for input - exiting\n", infile);
    return -2;
  }
  fdOut = fopen(outfile, "w");
  if (fdOut == NULL)
  {
    fprintf(stderr, "cannot open %s for output - exiting\n", outfile);
    fclose(fdIn);
    return -3;
  }

  chars_read = readln_fed(&inbuf, &sz_inbuf, fdIn);

  while (chars_read != EOF)
  {
    if (chars_read == 0)
    { // not EOF, but nothing to process
      chars_read = readln_fed(&inbuf, &sz_inbuf, fdIn);
      continue;
    }

#ifdef DEBUG
    printf("inbuf: %s\n", inbuf);
#endif

    Zipfed *pZipfed = new Zipfed();
    if (pZipfed->parse_zip_federal(inbuf) != 0)
    {
      fprintf(stderr, "failed to process input record - exiting\n");
      fclose(fdIn);
      fclose(fdOut);
      return -4;
    }

    llist.push_front(pZipfed);

    chars_read = readln_fed(&inbuf, &sz_inbuf, fdIn);
  }

  std::forward_list<Zipfed *>::iterator it = llist.begin();
  while (it != llist.end())
  {
    Zipfed *pTmpZipfed = *it;

    switch (pTmpZipfed->getState()[0])
    {
    case 'M':
      if (pTmpZipfed->getState() == "MA")
      {

        pTmpZipfed->print(fdOut);
      }
      break;
      default:
      break;
    }
    it++;
  }

  while (!llist.empty())
  {
    llist.pop_front();
  }

  return 0;
}