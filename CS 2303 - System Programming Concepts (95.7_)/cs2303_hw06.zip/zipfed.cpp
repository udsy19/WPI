#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <string>
#include "zipfed.hpp"
#include <iostream>


Zipfed::Zipfed () {
  zipcode = "";
  zctype = INVALID;
  city = "";
  state = "";
  lat = 0.0;
  lon = 0.0;
}

/**

    @brief Parses a string containing comma-separated values for the Federal ZIP Code dataset
    @param csv The input string containing comma-separated values
    @return Returns 0 if successful, -1 if input is null or empty, or -3 if the first column is "RecordNumber"
    */

int Zipfed::parse_zip_federal (char *csv) {
  const char* delim = ","; // comma is the delimiter
  const int QUOTE = '\"';  // the quote character, we strip this from input.
  std::string token;       // This  will be the token we read using strtok
  int recnum = 0;          // Each record in CSV is sequentially numbered
  
  if ((csv == NULL) || (strlen(csv) == 0)) {
    return -1;
  }


  token = strtok(csv, delim);
  if (strcmp(token.c_str(), "\"RecordNumber\"") == 0) {
    return -3;
  }
  // first column is the record num. We don't store this
  recnum = atoi(token.c_str());

  token = strtok(NULL, delim);
  token.erase(std::remove(token.begin(), token.end(), QUOTE), token.end());
  while (token.size() < 5) {
    token.insert(0, 1, '0');
  }
  zipcode = token;

  token = strtok(NULL, delim);
  token.erase(std::remove(token.begin(), token.end(), QUOTE), token.end());
  if (token.compare("STANDARD") == 0) {
    zctype = STANDARD;
  } else if (token.compare("PO_BOX") == 0) {
    zctype = PO_BOX;
  } else if (token.compare("UNIQUE") == 0) {
    zctype = UNIQUE;
  } else if (token.compare("MILITARY") == 0) {
    zctype = MILITARY;
  } else {
    zctype = INVALID;
  }

  // fourth column is the city
  token = strtok(NULL, delim);
  token.erase(std::remove(token.begin(), token.end(), QUOTE), token.end());
  city = token;

  // fifth column is the 2-character State code as string
  token = strtok(NULL, delim);
  token.erase(std::remove(token.begin(), token.end(), QUOTE), token.end());
  state = token;

  // sixth column is LocationType, we don't want that - don't process input
  token = strtok(NULL, delim);

  // seventh & eigth columns are Lat/Lon - these fields are not quoted
  token = strtok(NULL, delim);
  lat = std::stof(token);
  token = strtok(NULL, delim);
  lon = std::stof(token);

  // Columns 9-11 (Zaxis. Yaxis, Zaxis) we don't care about
  token = strtok (NULL, delim);
  token = strtok (NULL, delim);
  token = strtok (NULL, delim);

  return 0;
}

int Zipfed::parse_cs2303 (char *csv)
{
	const char *delim = ",";
	std::string token;
	int recnum = 0;

	if ((csv == NULL) || (strlen(csv) == 0))
		return -1;

	token = strtok(csv, delim);
	while (token.size() < 5)
		token.insert(0, 1,'0');

	zipcode = token;

	token = strtok(NULL, delim);
	if (token.compare("STANDARD") == 0)
		zctype = STANDARD;
	else if (token.compare("PO_BOX") == 0)
		zctype = PO_BOX;
	else if (token.compare("UNIQUE") == 0)
		zctype = UNIQUE;
	else if (token.compare("MILITARY") == 0)
		zctype = MILITARY;
	else
		zctype = INVALID;

	token = strtok(NULL, delim);
	city = token;

	token = strtok(NULL, delim);
	state = token;

	token = strtok(NULL, delim);
	lat = std::stof(token);
	token = strtok(NULL, delim);
	lon = std::stof(token);

	return 0;
}

/**

    @brief Parses a string containing comma-separated values for the CS2303 dataset
    @param csv The input string containing comma-separated values
    @return Returns 0 if successful, -1 if input is null or empty
    */

void Zipfed::print(void)
{
	printf ("%s,", zipcode.c_str());
	switch (zctype)
	{
		case STANDARD:
			printf("STANDARD,");
			break;
		case PO_BOX:
			printf("PO_BOX,");
			break;
		case UNIQUE:
			printf("UNIQUE,");
			break;
		case MILITARY:
			printf("MILITAERY,");
			break;
		case INVALID:
			printf("INVALID,");
			break;
		default:
			printf(",");
			break;
	}

	printf("%s, %s,", city.c_str(), state.c_str());
	printf("%f, %f\n", lat, lon);
}

void Zipfed::print (FILE *dest) {
  fprintf (dest, "%s,", zipcode.c_str());
  switch (zctype) {
  case STANDARD:
    fprintf(dest, "STANDARD,");
    break;
  case PO_BOX:
    fprintf(dest, "PO_BOX,");
    break;
  case UNIQUE:
    fprintf(dest, "UNIQUE,");
    break;
  case MILITARY:
    fprintf(dest, "MILITARY,");
    break;
  case INVALID:
    fprintf(dest, "INVALID,");
    break;
  default:
    fprintf(dest, ",");
    break;
  }
  fprintf(dest, "%s,%s,", city.c_str(), state.c_str());
  fprintf(dest, "%f,%f\n", lat, lon);
  
  return;

}

std::string Zipfed::getState()
{
	return state;
}

std::string Zipfed::getCity()
{
	return city;
}

bool Zipfed::is_from(std::vector<std::string> &queries)
{
	std::string query_city, c;

	for (int i = 0; i < queries.size(); i++)
	{
		query_city = queries.at(i);
		for(int j = 0; j < query_city.size(); j++)
		{
			std::string c(1, toupper(query_city.at(j)));
			query_city.replace (j, 1, c);
		}

		if (city.compare(query_city) ==0)
			return true;
	}
	return false;
}
