#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "sort.h"


void timesort (int a[], int count, int sort_type) {
    struct timeval start_time;
    struct timeval end_time;
    struct timeval sort_time;

    printf("Unsorted array:\n");
    print_int_array(a, count);

    if (sort_type == 1){

    gettimeofday(&start_time, NULL);
    sort_descending(a, count);
    gettimeofday(&end_time, NULL);

    printf("\n");
	  printf("Starting Time (s) and (m/s): ");
	  print_timeval(start_time);
	
	  printf("\n");
	  printf("Ending Time (s) and (m/s): ");
  	print_timeval(end_time);

    sort_time = timediff(start_time, end_time);
    printf("Sort time: ");
    print_timeval(sort_time);

    printf("Sorted array:\n");
    print_int_array(a, count);

    return;

    }

    else if (sort_type == 2){
    
    gettimeofday(&start_time, NULL);
    alt_sort_descending(a, count);
    gettimeofday(&end_time, NULL);

    printf("\n");
	  printf("Starting Time (s) and (m/s): ");
	  print_timeval(start_time);
	
	  printf("\n");
	  printf("Ending Time (s) and (m/s): ");
  	print_timeval(end_time);

    sort_time = timediff(start_time, end_time);
    printf("Sort time: ");
    print_timeval(sort_time);

    printf("Sorted array:\n");
    print_int_array(a, count);

    return;

    }
    else{
          printf("Type '1' for Array Sorting Index or Type 2 for Pointer Sorting");
         
          return;
    }
}
