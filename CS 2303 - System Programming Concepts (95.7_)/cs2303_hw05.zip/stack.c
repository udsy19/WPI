
#include <stddef.h>
#include <stdlib.h>
#include "stack.h"
#include <stdio.h>


/**
 * @Author Udaya Vijay Anand
 * 
 * @struct Stack
 * @brief A stack data structure.
 *
 * @var Stack::elements
 * Pointer to the stack's elements.
 *
 * @var Stack::top
 * Pointer to the top element of the stack.
 *
 * @var Stack::base
 * Pointer to the bottom element of the stack.
 *
 * @var Stack::num_elements
 * Number of elements currently in the stack.
 *
 * @var Stack::max_size
 * Maximum number of elements the stack can hold.
 */




/**
 * @brief Creates a new stack.
 *
 * @param size The maximum number of elements the stack can hold.
 *
 * @return A pointer to the new stack on success, or NULL on failure.
 */


Stack * create (int size) {
  Stack * stack = NULL;
  void* array = NULL;

  stack = (Stack *) calloc (1, sizeof(Stack));
  if (stack == NULL) {
    return stack;
  }
  stack->elements = (void*) calloc(size,sizeof(void*));
  if (stack->elements == NULL){
    destroy(stack);
    return NULL;
  }

  stack->top = stack->base = (void**) stack->elements;
  stack->max_size = size;
  return stack;
}

/**
 * @brief Destroys a stack and frees its memory.
 *
 * @param stack A pointer to the stack to be destroyed.
 */

void destroy (Stack *stack) {
  free(stack->elements);
  free(stack);
  return;
}

/**
 * @brief Checks whether a stack is empty.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return 1 if the stack is empty, 0 otherwise.
 */


int isempty(Stack *stack) {
  return (!numelements(stack));
}

/**
 * @brief Returns the number of elements in a stack.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return The number of elements in the stack.
 */

int numelements(Stack *stack) {
  return stack->num_elements;
}

/**
 * @brief Returns the maximum number of elements a stack can hold.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return The maximum number of elements the stack can hold.
 */

int maxelements (Stack *stack) {
  return stack->max_size;
}

/**
 * @brief Returns the top element of a stack without removing it.
 *
 * @param stack A pointer to the stack to be peeked.
 *
 * @return A pointer to the top element of the stack on success, or NULL if the stack is empty.
 */

void * peek (Stack *stack) {
  if (stack->num_elements == 0) {
    return (void *) NULL;
  }


  void **top_element;
  top_element = stack->top;
  top_element--;
  return (*top_element);
}

/**
 * @brief Removes and returns the top element of a stack.
 *
 * @param stack A pointer to the stack to be popped.
 *
 * @return A pointer to the top element of the stack on success, or NULL if the stack is empty.
 */

void * pop (Stack *stack) {
  if (stack->num_elements == 0) {
    return (void *) NULL;
  }

  void *top_element;
  stack->top--;
  top_element = *(stack->top);
  *(stack->top) = (void *) NULL;
  stack->num_elements--;

  return (top_element);
}

/**
 * @brief Adds a new element to the top of a stack.
 *
 * @param stack A pointer to the stack to be pushed.
 * @param element A pointer to the element to be added to the stack.
 *
 * @return A pointer to the new element on success, or NULL if the stack is full.
 */

void * push (Stack *stack, void *element) {
  if (stack->max_size == (stack->top - stack->base)) {
    return (void *) NULL;
  }

  *(stack->top) = element;
  stack->top++;
  stack->num_elements++;
  return element;
}
