/**
 * @file stack.h
 * Definition of a stack.
 */

#ifndef STACK_H
#define STACK_H

/**
 * @author Udaya Vijay Anand
 * @struct Stack
 * @brief A stack data structure.
 *
 * @var Stack::num_elements
 * Number of elements currently in the stack.
 *
 * @var Stack::top
 * Pointer to the top element of the stack.
 *
 * @var Stack::base
 * Pointer to the bottom element of the stack.
 *
 * @var Stack::elements
 * Pointer to the stack's elements.
 *
 * @var Stack::max_size
 * Maximum number of elements the stack can hold.
 */
typedef struct stack {
  int num_elements;
  void **top;
  void **base;
  void *elements;
  int max_size;
} Stack;

/**
 * @brief Returns the top element of a stack without removing it.
 *
 * @param stack A pointer to the stack to be peeked.
 *
 * @return A pointer to the top element of the stack on success, or NULL if the stack is empty.
 */
void *peek(Stack *stack);

/**
 * @brief Removes and returns the top element of a stack.
 *
 * @param stack A pointer to the stack to be popped.
 *
 * @return A pointer to the top element of the stack on success, or NULL if the stack is empty.
 */
void *pop(Stack *stack);

/**
 * @brief Adds a new element to the top of a stack.
 *
 * @param stack A pointer to the stack to be pushed.
 * @param element A pointer to the element to be added to the stack.
 *
 * @return A pointer to the new element on success, or NULL if the stack is full.
 */
void *push(Stack *stack, void *element);

/**
 * @brief Checks whether a stack is empty.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return 1 if the stack is empty, 0 otherwise.
 */
int isempty(Stack *stack);

/**
 * @brief Returns the number of elements in a stack.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return The number of elements in the stack.
 */
int numelements(Stack *stack);

/**
 * @brief Returns the maximum number of elements a stack can hold.
 *
 * @param stack A pointer to the stack to be checked.
 *
 * @return The maximum number of elements the stack can hold.
 */
int maxelements(Stack *stack);

/**
 * @brief Creates a new stack.
 *
 * @param size The maximum number of elements the stack can hold.
 *
 * @return A pointer to the new stack on success, or NULL on failure.
 */
Stack *create(int size);

/**
 * @brief Destroys a stack and frees its memory.
 *
 * @param stack A pointer to the stack to be destroyed.
 */
void destroy(Stack *stack);

#endif
