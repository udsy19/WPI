/**
 * @file stacktest2.c
 * Program to read lines from standard input, reverse each line, and print the reversed lines in the original order.
 */

#include <stdio.h>
#include "stack.h"
#include <stdlib.h>
#include <string.h>

/**
 * @author Udaya Vijay Anand
 * @brief Main function for the program.
 *
 * @param argc The number of command-line arguments.
 * @param argv An array of strings containing the command-line arguments.
 *
 * @return 0 on success, non-zero on failure.
 */

int main(int argc, char *argv[]) {
  Stack* reverse_stack;
  void** lines = malloc(10000*sizeof(void*));
  void** lines_ptr = lines;
  void** clean_lines = lines;
  int size_keep = 0;
  char* line = NULL;
  char* line_ptr;
  size_t len = 0;
  size_t read;

  reverse_stack = create(atoi(argv[1]));

  while ((read = getline(&line, &len, stdin)) != -1) {
    line[strcspn(line, "\n")] = '\0';
    line_ptr = (char*) malloc(strlen(line)*sizeof(char));
    *lines = (void*) malloc(strlen(line)*sizeof(char));
    strcpy(line_ptr, line);
    for (int i = 0; i < strlen(line); i++) {
      push(reverse_stack, &line_ptr[i]);
    }
    for (int j = 0; j < strlen(line); j++) {
      line[j] = *((char*) pop(reverse_stack));
    }
    strcpy((char*) *lines, line);
    lines++;
    size_keep++;
    free(line_ptr);
  }

  for (int j = 0; j < size_keep; j++) {
    printf("%s\n", (char*) *lines_ptr);
    lines_ptr++;
    lines--;
  }

  for (int x = 0; x < size_keep; x++) {
    free(lines[x]);
  }

  free(clean_lines);
  destroy(reverse_stack);
  free(line);
  return 0;
}
