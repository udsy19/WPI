/** Source file with functions to operate on dynamic structure
 *
 * @author Blake Nelson
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include "struct_dynamic.h"

/** Function to create a dynamic struct. We allocate the structure 
 * which has a pointer to memory for an array of C String pointers as well as 
 * the number of strings stored in the array and pointers to the 
 * first and last elements
 *
 * @return a pointer to the DSTRUCT allocated
 */
DSTRUCT * dscreate () {
  DSTRUCT *pdstruct;

  /* allocate memory for the DSTRUCT. This will include only a pointer to the 
   * array of pointers to strings (pStrings). The array of pointers will be
   * separately allocated (2 allocations) and then we set the pointer to the
   * array of pointers to character strings
   *
   * Note: we could also call malloc( 1 * sizeof(DSTRUCT)); to allocate the 
   *       struct and then malloc (SZ_DYNAMIC_MEM * sizeof(char *)): for the 
   *       array of pointers to C strings
   * Note2: malloc() and calloc() return a void*, we cast to the 
   *        appropriate data type which is DSTRUCT* or char* as appropriate
   */
  pdstruct = (DSTRUCT *) calloc(1, sizeof(DSTRUCT));
  if (pdstruct == NULL) {
    fprintf (stderr, "dscreate: failed to allocate DSTRUCT memory\n");
    return NULL;
  }

  /* allocate memory for storing the pointers to the character strings
   * In the static struture, this array is part of the SSTRUCT. In the 
   * DSTRUCT we only have a pointer to memory external to DSTRUCT, so we
   * allocate that memory separately and point to it.
   */
  pdstruct->pStrings = (char **) calloc (SZ_DYNAMIC_MEM, sizeof(char *));
  if (pdstruct->pStrings == NULL) {
    fprintf (stderr, "dscreate: failed to allocate pString array memory\n");
    free (pdstruct);
    return NULL;
  }
  
  /* calloc set the memory allocated to zero values, but we'll set the
   * array to null pointers for demonstration purposes.
   */
  // first set the pString array to NULL pointers using pointers
  pdstruct->pStr = pdstruct->pStrings;
  for (int index = 0; index < SZ_DYNAMIC_MEM; index++, pdstruct->pStr++) {
    *pdstruct->pStr = (char *) NULL;
  }
  
  // now, do the same thing treating pString as an array to show equivalence
  for (int index = 0; index < SZ_DYNAMIC_MEM; index++) {
    pdstruct->pStrings[index] = (char *) NULL;
  }

  /* Let's inialize the pointers to the start and end of the array storage
   */
  pdstruct->pFirst = &pdstruct->pStrings[0];
  pdstruct->pLast = &pdstruct->pStrings[SZ_DYNAMIC_MEM-1];
  pdstruct->pStr = (char **) NULL;

  // No elements stored in the array yet
  pdstruct->numStrings = 0;

  return pdstruct;
}

/** Function to insert a string at a specific position in the array
 * using specified index into the array
 *
 * @param pdstruct is the DSTRUCT to work with
 * @param str is the C string to insert
 * @param index is the position in the array to insert the string
 * @return pointer to the string that was added to array
 */
char *ins_array_dynamic (DSTRUCT *pdstruct, char *str, int index) {
  if (index < 0 || index >= SZ_DYNAMIC_MEM) {
    fprintf (stderr, "ins_array_dynamic: index out of bounds\n");
    return NULL;
  }

  pdstruct->pStrings[index] = str;
  return pdstruct->pStrings[index];
}

/** Function to insert a string at a specific position in the array
 * using specified index as the position in the array
 *
 * @param pdstruct is the DSTRUCT to work with
 * @param str is the C string to insert
 * @param index is the position in the array to insert the string
 * @return pointer to the string that was added to array
 */
char *ins_ptr_dynamic (DSTRUCT *pdstruct, char *str, int index) {
  if (index < 0 || index >= SZ_DYNAMIC_MEM) {
    fprintf (stderr, "ins_ptr_dynamic: index out of bounds\n");
    return NULL;
  }

  // advance the pointer the right number of positions to write into the array
  pdstruct->pStr = &pdstruct->pStrings[0];
  for (int i = 0; i < index; i++) {
    pdstruct->pStr++;
  }
  *pdstruct->pStr = str;
  return *pdstruct->pStr;
}

/** Function to remove and return a string from a specific position in the
 * array using a specified index as the index into the array
 *
 * @param pdstruct is a pointer to DSTRUCT to work with
 * @param index is the postion in the array to remove string from
 * @return pointer to the string removed from the array
 */
char *rem_array_dynamic (DSTRUCT *pdstruct, int index) {
  char *pStr;
  
  if (index < 0 || index >= SZ_DYNAMIC_MEM) {
    fprintf (stderr, "rem_array_dynamic: index out of bounds\n");
    return NULL;
  }

  pStr = pdstruct->pStrings[index];
  pdstruct->pStrings[index] = NULL;
  pdstruct->numStrings--;
  return pStr;
}

/** Function to remove and return  a string from a specific position in the
 * array using a specified index as the index into the array
 *
 * @param pdstruct is a pointer to DSTRUCT to work with
 * @param index is the postion in the array to remove string from
 * @return pointer to the string removed from the array
 */
char *rem_ptr_dynamic (DSTRUCT *pdstruct, int index) {
  char *pStr;
  
  if (index < 0 || index >= SZ_DYNAMIC_MEM) {
    fprintf (stderr, "rem_prt_dynamic: index out of bounds\n");
    return NULL;
  }

  // advance the pointer the right number of positions to write into the array
  pdstruct->pStr = &pdstruct->pStrings[0];
  for (int i = 0; i < index; i++) {
    pdstruct->pStr++;
  }
  pStr = *pdstruct->pStr;
  *pdstruct->pStr = NULL;
  pdstruct->numStrings--;
  return pStr;
}

