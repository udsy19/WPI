/** Program to demonstrate static allocation and dynamic allocation of
 * array as a field in a C struct
 *
 * @author Blake Nelson
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struct_static.h"
#include "struct_dynamic.h"

int main () {
  SSTRUCT *pss;
  DSTRUCT *pds;

  char s1[] = "String One";
  char s2[] = "String Two";
  char s3[] = "String Three";
  char s4[] = "String Four";
  char s5[] = "String Five";
  char *tmp;
  char *tmp2;

  // Create a structure with statically allocated storage array
  pss = sscreate ();
  if (pss != NULL) {
    printf ("SUCCESS creating Static Structure\n");
  } else {
    printf ("FAILED to create Static Structure\n");
  }

  // Create a structure with dynamically allocated storage array
  pds = dscreate ();
  if (pds != NULL) {
    printf ("SUCCESS creating Dynamic Structure\n");
  } else {
    printf ("FAILED to create Dynamic Structure\n");
  }

  // Add strings into static structure using array indexes
  for (int i = 0; i < 5; i++) {
    switch (i) {
    case 0:
      tmp = strdup(s1);
      tmp2 = strdup(s1);
      break;
    case 1:
      tmp = strdup(s2);
      tmp2 = strdup(s2);
      break;
    case 2:
      tmp = strdup(s3);
      tmp2 = strdup(s3);
      break;
    case 3:
      tmp = strdup(s4);
      tmp2 = strdup(s4);
      break;
    case 4:
      tmp = strdup(s5);
      tmp2 = strdup(s5);
      break;
    }

    // insert the string into array at index i
    ins_array_static(pss, tmp, i);
    ins_array_dynamic(pds, tmp2, i);
  }
      
  // Retrieve and print the strings we just stored
  for (int i = 0; i < 5; i++) {
    tmp = rem_array_static(pss, i);
    printf("static_struct had string \"%s\" at index %d\n", tmp, i);
    free (tmp);
    tmp = NULL;
    
    tmp2 = rem_array_dynamic(pds, i);
    printf("dynamic_struct had string \"%s\" at index %d\n", tmp2, i);
    free (tmp2);
    tmp2 = NULL;
  }

  // space out the printing on the terminal
  printf ("\n\n");
  
  // Add strings into static structure using pointer manipulation
  for (int i = 0; i < 5; i++) {
    switch (i) {
    case 0:
      tmp = strdup(s1);
      tmp2 = strdup(s1);
      break;
    case 1:
      tmp = strdup(s2);
      tmp2 = strdup(s2);
      break;
    case 2:
      tmp = strdup(s3);
      tmp2 = strdup(s3);
      break;
    case 3:
      tmp = strdup(s4);
      tmp2 = strdup(s4);
      break;
    case 4:
      tmp = strdup(s5);
      tmp2 = strdup(s5);
      break;
    }

    // insert the string into array at index i
    ins_ptr_static(pss, tmp, i);
    ins_ptr_dynamic(pds, tmp2, i);
  }
      
  // Retrieve and print the strings we just stored
  for (int i = 0; i < 5; i++) {
    tmp = rem_array_static(pss, i);
    printf("static_struct had string \"%s\" at index %d\n", tmp, i);
    free (tmp);
    tmp = NULL;
    
    tmp2 = rem_array_dynamic(pds, i);
    printf("dynamic_struct had string \"%s\" at index %d\n", tmp2, i);
    free (tmp2);
    tmp2 = NULL;
  }
  
  return 0;
}
