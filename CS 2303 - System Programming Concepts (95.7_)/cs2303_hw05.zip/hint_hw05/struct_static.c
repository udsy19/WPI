/** Source file with functions to operate on static structure
 *
 * @author Blake Nelson
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include "struct_static.h"

/** Function to create a static struct. We allocate the structure 
 * which has memory for an array of C String pointers as well as 
 * the number of strings stored in the array and pointers to the 
 * first and last elements
 *
 * @return a pointer to the SSTRUCT allocated
 */
SSTRUCT * sscreate () {
  SSTRUCT *psstruct;

  /* allocate memory for the SSTRUCT. This will include the array of 
   * pointers to strings (pStrings)
   *
   * Note: we could also call malloc( 1 * sizeof(SSTRUCT));
   * Note2: malloc() and calloc() return a void*, we cast to the 
   *        appropriate data type which is SSTRUCT*
   */
  psstruct = (SSTRUCT *) calloc(1, sizeof(SSTRUCT));
  if (psstruct == NULL) {
    fprintf (stderr, "sscreate: failed to allocate SSTRUCT memory\n");
    return NULL;
  }

  /* calloc set the memory allocated to zero values, but we'll set the
   * array to null pointers for demonstration purposes.
   */
  // first set the pString array to NULL pointers treating it like an array
  for (int index = 0; index < SZ_STATIC_AR; index++) {
    psstruct->pStrings[index] = (char *) NULL;
  }

  // now, let's do the same thing using pointers to show equivalence
  psstruct->pStr = &psstruct->pStrings[0];
  for (int index = 0; index < SZ_STATIC_AR; index++, psstruct->pStr++) {
    *psstruct->pStr = (char *) NULL;
  }
  
  /* Let's inialize the pointers to the start and end of the array storage
   */
  psstruct->pFirst = &psstruct->pStrings[0];
  psstruct->pLast = &psstruct->pStrings[SZ_STATIC_AR-1];
  psstruct->pStr = (char **) NULL;

  // No elements stored in the array yet
  psstruct->numStrings = 0;

  return psstruct;
}

/** Function to insert a string at a specific position in the array
 * using specified index into the array
 *
 * @param psstruct is the SSTRUCT to work with
 * @param str is the C string to insert
 * @param index is the position in the array to insert the string
 * @return pointer to the string that was added to array
 */
char *ins_array_static (SSTRUCT *psstruct, char *str, int index) {
  if (index < 0 || index >= SZ_STATIC_AR) {
    fprintf (stderr, "ins_array_static: index out of bounds\n");
    return NULL;
  }

  psstruct->pStrings[index] = str;
  psstruct->numStrings++;
  return psstruct->pStrings[index];
}

/** Function to insert a string at a specific position in the array
 * using specified index as the position in the array
 *
 * @param psstruct is the SSTRUCT to work with
 * @param str is the C string to insert
 * @param index is the position in the array to insert the string
 * @return pointer to the string that was added to array
 */
char *ins_ptr_static (SSTRUCT *psstruct, char *str, int index) {
  if (index < 0 || index >= SZ_STATIC_AR) {
    fprintf (stderr, "ins_ptr_static: index out of bounds\n");
    return NULL;
  }

  // advance the pointer the right number of positions to write into the array
  psstruct->pStr = &psstruct->pStrings[0];
  for (int i = 0; i < index; i++) {
    psstruct->pStr++;
  }
  *psstruct->pStr = str;
  psstruct->numStrings++;
  return *psstruct->pStr;
}

/** Function to remove and return  a string from a specific position in the
 * array using a specified index as the index into the array
 *
 * @param psstruct is a pointer to SSTRUCT to work with
 * @param index is the postion in the array to remove string from
 * @return pointer to the string removed from the array
 */
char *rem_array_static (SSTRUCT *psstruct, int index) {
  char *pStr;
  
  if (index < 0 || index >= SZ_STATIC_AR) {
    fprintf (stderr, "rem_array_static: index out of bounds\n");
    return NULL;
  }

  pStr = psstruct->pStrings[index];
  psstruct->pStrings[index] = NULL;
  psstruct->numStrings--;
  return pStr;
}

/** Function to remove and return  a string from a specific position in the
 * array using a specified index as the index into the array
 *
 * @param psstruct is a pointer to SSTRUCT to work with
 * @param index is the postion in the array to remove string from
 * @return pointer to the string removed from the array
 */
char *rem_ptr_static (SSTRUCT *psstruct, int index) {
  char *pStr;
  
  if (index < 0 || index >= SZ_STATIC_AR) {
    fprintf (stderr, "rem_prt_static: index out of bounds\n");
    return NULL;
  }

  // advance the pointer the right number of positions to write into the array
  psstruct->pStr = &psstruct->pStrings[0];
  for (int i = 0; i < index; i++) {
    psstruct->pStr++;
  }
  pStr = *psstruct->pStr;
  *psstruct->pStr = NULL;
  psstruct->numStrings--;
  return pStr;
}


