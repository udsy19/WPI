/** Declarations for a C structure with static allocation of storage
 *
 * @author Blake Nelson
 */
#ifndef STRUCT_STATIC_H
#define STRUCT_STATIC_H

#define SZ_STATIC_AR (10)

/** Declare a structure which can store pointer to C Strings (arrays of
 *  characters with a null terminator. Each element of the array can 
 *  hold a pointer to a string. 
 *
 *  What this means is the compiler will allocate an array of 10 (index
 *  0 through index 9 inclusive). At each index I can store a pointer to 
 *  character. This means it points to some memory location where the first
 *  character of a C string is stored. We point to the first character of the 
 *  string and know the end of the string by looking for the null terminator
 *  '\0' at the end of the string.
 *
 *  We also keep track of the number of strings we currently have in array
 *
 *  We have a pointer to the first array position, in that position can be a
 *  pointer to a string. Thus, pFirst is a pointer to a char pointer.
 *
 *  We have a pointer to the last array position, in that position can be a
 *  pointer to a string, Thus, pLast is a pointer to a char pointer.
 *
 *  Lastly, we have a pointer that we can use to point to any position. Again, 
 *  at each index of the array, we can have a pointer to a string. Thus, pStr
 *  is also a pointer to a pointer to char.
 *
 *  Note: Any of these pointers can point to any index of the array. I have 
 *  chosen in this example to set one to the beginning (first index of the
 *  array), one to the end of the array (last index of the array), and one
 *  that will point to any index of the array for demonstration purposes.
 *
 */
typedef struct sstruct {
  char *pStrings[SZ_STATIC_AR];  /**< array storing 10 pointers to C strings */
  int numStrings;                /**< number of strings currently in array */
  char **pFirst;                 /**< pointer to the first string in the array */
  char **pLast;                  /**< pointer to the last string in the array */
  char **pStr;                   /**< pointer to any string in the array */
} SSTRUCT;                       /**< SSTRUCT is for Static Struct */

// prototype declaraions
SSTRUCT * sscreate ();
char *ins_array_static (SSTRUCT *psstruct, char *str, int index);
char *ins_ptr_static (SSTRUCT *psstruct, char *str, int index);
char *rem_array_static (SSTRUCT *psstruct, int index);
char *rem_ptr_static (SSTRUCT *psstruct, int index);

#endif
