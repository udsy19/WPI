
Name: Udaya Vijay Anand
Description:

The 'stacktest' program demonstrates the use of a stack data structure. It asks the user to input an integer which specifies the size of the stack, and then reads input from the user line by line and pushes each line onto the stack before popping them.

The 'stacktest_dbg' program is similar to 'stacktest', but it also prints out debug messages indicating what elements are being pushed onto and popped off of the stack.

The 'stacktest2' program takes an integer as input which specifies the size of the stack to be used for reversing the character order of each line of a string. The size must be at least as large as the number of characters per line, and the array used to store the reversed strings has a maximum size of 10000. This means that 'stacktest2' can process up to 10000 lines of input. The program then prints out the reversed lines in the same order as they were input.

To build the programs, the following commands are available:

    'make' turns the .c file into an .o file, links the files, and creates an executable.
    'make docs' generates Doxygen documentation for all programs.
    'make clean' removes all .o files and executables.

There are also several commands for running the programs, a few are listed below:

    './stacktest stack_size1'
    './stacktest2 stack_size1'
    'cat input.txt'
    ./stacktest stack_size1' 
    ./stacktest stack_size2' 

These commands allow for the input of text files and specify the size of the stacks to be used by each program.