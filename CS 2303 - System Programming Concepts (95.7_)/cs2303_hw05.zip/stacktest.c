/**
 * @file stacktest.c
 * Program to read lines from standard input, store them in a stack, and print them in reverse order.
 */

#include <stdio.h>
#include "stack.h"
#include <stdlib.h>
#include <string.h>

/**
 * @author Udaya Vijay Anand
 * @brief Main function for the program.
 *
 * @param argc The number of command-line arguments.
 * @param argv An array of strings containing the command-line arguments.
 *
 * @return 0 on success, non-zero on failure.
 */
int main(int argc, char *argv[]) {

  void** lines = malloc(atoi(argv[1])*sizeof(void*));
  void** start_lines = lines;
  void** clean_lines = lines;
  int free_check = 0;

  Stack *the_stack;
  char* line = NULL;
  size_t len = 0;
  size_t read;

  the_stack = create(atoi(argv[1]));

  while ((read = getline(&line, &len, stdin)) != -1) {
    line[strcspn(line, "\n")] = '\0';
    *lines = (void*) malloc(strlen(line)*sizeof(char));
    strcpy((char*) *lines,line);
    push(the_stack, *lines);
    lines++;
    free_check++;
  }

  while (!isempty(the_stack)) {
    char *element = (char *) pop(the_stack);
    printf("%s\n", element);
  }

  destroy(the_stack);

  for (int j = 0; j < free_check;j++){
    free(clean_lines[j]);
  }
  free(start_lines);
  free(line);

  return 0;
}
