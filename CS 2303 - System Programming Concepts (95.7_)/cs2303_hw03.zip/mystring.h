/**
 * @file mystring.h
 * @brief This file contains declaration of functions for string manipulation.
 * @author Udaya Vijay Anand
 */

#ifndef MYSTRING_H
#define MYSTRING_H

/**
 * @brief Duplicates a given string.
 *
 * This function creates a copy of the string pointed to by `src` and returns a
 * pointer to the newly created string. The memory for the new string is dynamically
 * allocated using malloc(). The caller is responsible for freeing the memory using
 * free().
 *
 * @param src The string to be duplicated.
 * @return A pointer to the duplicated string.
 */

char* mystrdup(const char* src);

/**
 * @brief Computes the length of a given string.
 *
 * This function calculates the length of the string pointed to by `str` excluding
 * the terminating null character.
 *
 * @param str The input string.
 * @return The length of the string.
 */

size_t mystrlen(const char* str);

/**
 * @brief Copies one string to another.
 *
 * This function copies the string pointed to by `b` to the array pointed to by `a`.
 *
 * @param a Pointer to the destination array.
 * @param b Pointer to the source array.
 * @return A pointer to the destination array.
 */

char* mystrcpy(char* a, char*b);

/**
 * @brief Concatenates two strings.
 *
 * This function appends the string pointed to by `source` to the end of the string
 * pointed to by `destination`. The resulting string is null-terminated.
 *
 * @param destination Pointer to the destination string.
 * @param source Pointer to the source string.
 * @return A pointer to the destination string.
 */

char *mystrcat(char *destination, const char *source);

/**
 * @brief Concatenates two strings up to a given length.
 *
 * This function appends at most `n` characters from the string pointed to by `source`
 * to the end of the string pointed to by `destination`. The resulting string is
 * null-terminated.
 *
 * @param destination Pointer to the destination string.
 * @param source Pointer to the source string.
 * @param n Maximum number of characters to append.
 * @return A pointer to the destination string.
 */

char *mystrncat(char *destination, const char *source, size_t n);

/**
 * @brief Copies a string to another up to a given length.
 *
 * This function copies at most `n` characters from the string pointed to by `src` to
 * the array pointed to by `dest`. If the end of the source string is reached before
 * `n` characters have been copied, the resulting string is padded with null characters
 * until a total of `n` characters have been written to the destination array.
 *
 * @param dest Pointer to the destination array.
 * @param src Pointer to the source array.
 * @param n Maximum number of characters to copy.
 * @return A pointer to the destination array.
 */

char *mystrncpy(char *dest, const char *src, size_t n);

/**
 * @brief Duplicates a given string up to a given length.
 *
 * This function creates a copy of at most `n` characters from the string pointed to
 * by `src` and returns a pointer to the newly created string. The memory for the new
 * string is dynamically allocated using malloc(). The caller is responsible for freeing
 * the memory using free().
 *
 * @param src The string to be duplicated.
 * @param n Maximum number of characters to duplicate.
 * @return A pointer to the duplicated string.
 */

char *mystrndup(const char *src, size_t n);
#endif