/**
 * @file ctest.c
 * @author Udaya Vijay Anand
 * @brief This is the main file for the program which demonstrates the functionality of the string manipulation functions.
 * This file contains the main function for testing custom string functions.
 * The custom string functions include: mystrcpy, mystrncat, mystrncpy, and mystrndup.
 * The tests check the functionality of each function.
 * The mystrcpy function copies a string from a source string to a destination string.
 * The mystrncat function concatenates a specified number of characters from a source string to the end of a destination string.
 * The mystrncpy function copies a specified number of characters from a source string to a destination string.
 * The mystrndup function duplicates a specified number of characters from a source string to a newly allocated string.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mystring.h"

const int MAX_CHARS = 20; // The maximum number of characters allowed in a string.

/**
 * @brief The main function of the program which demonstrates the string manipulation functions.
 * @return 0 on success.
 */

int main()
{
  char a1[MAX_CHARS + 1]; // Array of characters

  char a2[] = "Hello"; // Array of characters

  char a3[MAX_CHARS + 1]; // Array of characters

  const char *p1 = "Hello"; // Pointer to a constant character.

  char *p2; // Pointer to a character.

  int copy_limit; // The maximum number of characters allowed to be copied from one string to another.

  char sample_string[] = "This is a sample string"; // Array of characters

  char source_string[] = "Source string"; // Array of characters

  char dest_string[MAX_CHARS - 10];
  char dest_string1[MAX_CHARS + 10];
  char dest_string2[MAX_CHARS];
  char dest_string3[MAX_CHARS];
  char dest_string4[MAX_CHARS];
  char dest_string5[MAX_CHARS];
  char dest_string6[MAX_CHARS];

  printf("Arrays: a1: %p, a2: %p, a3: %p\n", a1, a2, a3);
  printf("Pointers: p1: %p, p2: %p\n", p1, p2);

  mystrcpy(a1, "Hi");
  mystrcpy(a3, "Hello, also");

  printf("\n");
  printf("C-string values:\n");
  printf("a1: %s\n", a1);
  printf("a2: %s\n", a2);
  printf("a3: %s\n", a3);

  /**
   * Prints the memory addresses of arrays a1, a2 and a3, and pointers p1 and p2.
   */
  a1[MAX_CHARS] = '\0';
  mystrcat(a1, a2);
  printf("\n");
  printf("After concatenating a2 to the end of a1\n");
  printf("a1: %s\n", a1);

  /**
   * Concatenates the contents of a2 to a1 with copy_limit as the maximum number
   * of characters that can be added.
   */
  copy_limit = MAX_CHARS - strlen(a1);
  printf("\n");
  printf("Concatenating a2 to a1, with copy_limit = %d\n", copy_limit);
  if (copy_limit > 0)
  {
    mystrncat(a1, a2, copy_limit);
  }
  printf("a1: %s\n", a1);

  /**
   * @brief Concatenates the contents of a3 to a1
   *
   * This function first calculates the copy limit as the maximum number of characters that can be copied from a3 to a1.
   * Then, it concatenates the contents of a3 to a1 using mystrncat() function, with copy_limit as the limit of characters to be copied.
   * Finally, it prints the contents of the concatenated string.
   */
  copy_limit = MAX_CHARS - strlen(a1);
  printf("\n");
  printf("Concatenating a3 to a1, with copy_limit = %d\n", copy_limit);
  if (copy_limit > 0)
  {
    mystrncat(a1, a3, copy_limit);
  }
  printf("a1: %s\n", a1);

  /**
   * @brief Duplicates a string
   *
   * This function first prints the address and contents of the original string a2.
   * Then, it duplicates the string a2 using mystrdup() function and prints the address and contents of the duplicate string.
   * Finally, it frees the duplicate string.
   */
  printf("\n");
  printf("Before dup, array a2 = %p, contents = %s\n", a2, a2);
  p2 = mystrdup(a2);
  printf("After dup, pointer p2 = %p, contents = %s\n", p2, p2);

  free(p2);
  printf("\n");

  /*----------------------------------------------------------------------------------------------------------------------------------------------------*/
  /*----------------------------------------------------------------------------------------------------------------------------------------------------*/

  // TESTING MYSTRCPY
  /**
      @brief Test for mystrcpy function
      This test prints the source string,
      then calls the mystrcpy function to copy the source string to the destination string.
      Finally, it prints the destination string to show the result of the copy.

  */
  printf("----- TEST MYSTRCPY ----->\n");
  printf("Source string is: %s\n", source_string);
  mystrcpy(dest_string, sample_string);
  printf("After copying source string to destination, then the destination would be: %s\n", source_string);
  printf("\n");

  // TESTING MYSTRNCAT AND MYSTRCAT
  /**
      @brief Test for mystrncat and mystrcat functions
      This test prints the source string and its length,
      then calls the mystrcpy function to copy the source string to three destination strings.
      Next, it calls the mystrcat and mystrncat functions to concatenate the source string to each of the three destination strings.
      The concatenation limits for each call to mystrncat are specified as 13, 14, and 8 characters.
      Finally, it prints the result of each concatenation to show the result of the tests.

  */
  printf("----- Testing out the data in mystract and mystrncat -----> \n");
  printf("The list of source string: %s\n", source_string);
  printf("The length of the source string would be: %ld\n", mystrlen(source_string));
  mystrcpy(dest_string1, sample_string);
  mystrcpy(dest_string2, sample_string);
  mystrcpy(dest_string3, sample_string);
  printf("\n");
  printf("The text (This is a sample string) is taken from the source to the destination: %s\n", mystrcat(dest_string, source_string));
  printf("\n");

  printf("The following text has a Copy Limit of 13 (same as the source string) and is taken from the source to the destination: %s\n", mystrncat(dest_string1, source_string, 13));
  printf("The following text has a Copy Limit of 16 (more than the source string) and is taken from the source to the destination: %s\n", mystrncat(dest_string2, source_string, 14));
  printf("The following text has a Copy Limit of 08 (less than the source string) and is taken from the source to the destination: %s\n", mystrncat(dest_string3, source_string, 8));
  printf("\n");

  // TESTING MYSTRNCPY
  /**
      @brief Testing function for mystrncpy
      This function tests the functionality of the custom function mystrncpy.
      It prints the source string and its length, then copies the source string to various destinations with different copy limits,
      and prints the result of the mystrncpy call for each destination.
      */
  printf("----- The following checks the elements of mystrncpy ----->\n");
  printf("Source string is: %s\n", source_string);
  printf("Length of source string s is: %ld\n", mystrlen(source_string));
  printf("\n");

  printf("The following text has a Copy Limit of 13. It copies the source string to the empty desination: %s\n", mystrncpy(dest_string4, source_string, 13));
  mystrcpy(dest_string5, "Example_1"); // Copy Example_1 to d5
  printf("The following text has a Copy Limit of 14. It copies the source string to the destination which contains 'Example_1': %s\n", mystrncpy(dest_string5, source_string, 14));
  mystrcpy(dest_string6, "Example_2"); // Copy Example_2 to d6
  printf("The following text has a Copy Limit of 08. It copies the source string to the destination which contains 'Example_2': %s\n", mystrncpy(dest_string6, source_string, 8));
  printf("\n");

  // TESING MYSTRNDUP
  /**

    @brief TESING MYSTRNDUP - A function to test the implementation of mystrndup function
    This function first displays the source string and its length using mystrlen function.
    Then, it creates 3 duplicates of the source string with copy limits 13, 14 and 8 using mystrndup function.
    Finally, it frees the memory allocated for the duplicates using free function.
    */
  printf("----- The following checks the elements of mystrndup ----->\n");
  printf("Source string is: %s\n", source_string);
  printf("Length of source string s is: %ld\n", mystrlen(source_string));
  printf("\n");
  char *a = mystrndup(source_string, 13);
  char *b = mystrndup(source_string, 14);
  char *c = mystrndup(source_string, 8);
  printf("The following text has a Copy Limit of 13 and the duplicate would be: %s\n", a);
  printf("The following text has a Copy Limit of 14 and the duplicate would be: %s\n", b);
  printf("The following text has a Copy Limit of 08 and the duplicate would be: %s\n", c);
  free(a);
  free(b);
  free(c);

  return 0;
}
