/**
 * @file new.c
 * @author Udaya Vijay Anand
 * @brief Main function that demonstrates the use of functions in mystruct.h, mystring.h and time.h libraries.
 */

#include <stdlib.h>
#include <stdio.h>
#include "mystruct.h"
#include "mystring.h"
#include "time.h"

/**
 * @brief Main function to demonstrate the usage of functions in mystruct.h, mystring.h and time.h libraries.
 * 
 * The function first creates 3 instances of Employee using the function make_employee and prints them using the print_employee function.
 * Then, it creates 3 random employees using the createRandomEmployee function and prints them using the print_employee function.
 * Next, it creates an array of 5 random employees using the createRandomEmployeeArray function and prints the array using the printEmployeeArray function.
 * It then demonstrates the shallow copy function shallowCopy by creating a shadow copy of the previous array and printing both the original and shadow copy arrays.
 * Finally, it demonstrates the deep copy function deepCopy by creating a deep copy of an array of 3 random employees and printing both the original and deep copy arrays.
 *
 * @return int 0 upon success.
 */

int main(){

  /**
   * @brief Pointer to an employee struct created using make_employee.
   */
  Employee* employee1 = make_employee("test",2001,2020);
  /**
   * @brief Pointer to an employee struct created using make_employee.
   */
  Employee* employee2 = make_employee("blahh",1979,2019);
  /**
   * @brief Pointer to an employee struct created using make_employee.
   */
  Employee* employee3 = make_employee("yeehaw",1995,2021);

  /**
   * @brief Demonstrates the use of print_employee to print individual employee information.
   */
  printf(" Printing Out: print_employee and printEmployee \n");
  print_employee(employee1);
  printf("\n");
  print_employee(employee2);
  printf("\n");
  print_employee(employee3);
  printf("\n");
  /**
   * @brief Frees the memory occupied by employee structs.
   */
  free(employee1);
  free(employee2);
  free(employee3);
  srand(time(NULL));

  /**
   * @brief Demonstrates the creation and printing of a single random employee using createRandomEmployee.
   */
  printf("Printing Out: createRandomEmployee function\n");
  /**
   * @brief Pointer to a randomly generated employee struct created using createRandomEmployee.
   */
  Employee* random_employee1 = createRandomEmployee();
  /**
   * @brief Pointer to a randomly generated employee struct created using createRandomEmployee.
   */
  Employee* random_employee2 = createRandomEmployee();
  /**
   * @brief Pointer to a randomly generated employee struct created using createRandomEmployee.
   */
  Employee* random_employee3 = createRandomEmployee();
  print_employee(random_employee1);
  printf("\n");
  print_employee(random_employee2);
  printf("\n");
  print_employee(random_employee3);
  printf("\n");
  /**
   * @brief Frees the memory occupied by randomly generated employee structs.
   */
  free(random_employee1);
  free(random_employee2);
  free(random_employee3);

  /**
   * @brief Demonstrates the creation and printing of an array of random employees using createRandomEmployeeArray and printEmployeeArray.
   */

  printf("Printing Out: createRandomEmployeeArray and printEmployeeArray function\n");
  Employee** array = createRandomEmployeeArray(5);
  printEmployeeArray(array, 5);
  printf("\n");

  freeArray(array,5);

 
 /**
  * @brief This file contains the implementation of shadowCopy and deepCopy functions. This function Prints the shadow copy of an array of employees
  * 
  * This function first creates a random array of employees using createRandomEmployeeArray(). 
  * Then, it creates a shadow copy of the array using shallowCopy() and prints it.
  * Finally, it frees both the original array and the shadow copy.
  */
  printf("Printing out shadowCopy function \n");
  printf("Original array: \n");
  Employee** array1 = createRandomEmployeeArray(5);
  printEmployeeArray(array1,5);
  printf("\n");
  Employee** array2 = shallowCopy(array1,5);
  printf("Shadow copy: \n");
  printEmployeeArray(array2,5);
  
  freeArray(array1,5);
  free(array2);

/**
  * @brief Prints the deep copy of an array of employees
  * 
  * This function first creates a random array of employees using createRandomEmployeeArray(). 
  * Then, it creates a deep copy of the array using deepCopy() and prints it.
  * Finally, it frees both the original array and the deep copy.
  */
  printf(" Printing Out: deppCopy Function\n");
  printf("Original array: \n");
  Employee** array3 = createRandomEmployeeArray(3);
  printEmployeeArray(array3,3);
  printf("\n");
  Employee** array4 = deepCopy(array3,3);
  printf("Deep Copy: \n");
  printEmployeeArray(array4,3);

  freeArray(array3,3);
  freeArray(array4,3);
}