/**
 * @file mystruct.c
 * @brief This file contains the declarations of the functions that perform operations on Employees.
 */

/**
 * @author Udaya Vijay Anand
 * @var Employee::name The name of the Employee.
 * @var Employee::birth_year The birth year of the Employee.
 * @var Employee::start_year The start year of the Employee.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mystring.h"
#define MAX_NAME_LENGTH 100 
typedef struct {
  char name[MAX_NAME_LENGTH];
  int birth_year;
  int start_year;
} Employee;

/**
 * @brief This function creates an Employee with the given name, birth year and start year.
 * @param name The name of the Employee.
 * @param birth_year The birth year of the Employee.
 * @param start_year The start year of the Employee.
 * @return Employee* A pointer to the created Employee.
 */

Employee* make_employee(char* name, int birth_year, int start_year) {
  Employee* emp = (Employee*) malloc(sizeof(Employee));
  strncpy(emp->name, name, MAX_NAME_LENGTH);
  emp->name[MAX_NAME_LENGTH - 1] = '\0';
  emp->birth_year = birth_year;
  emp->start_year = start_year;
  return emp;
}

/**
 * @brief This function prints the details of an Employee.
 * @param emp The Employee to be printed.
 */

void print_employee(Employee* emp) {
  printf("Name: %s\n", emp->name);
  printf("Birth year: %d\n", emp->birth_year);
  printf("Start year: %d\n", emp->start_year);
}

/**
 * @brief This function generates a random character.
 * @return char The generated random character.
 */

char generate_random_char() {
    //srand(time(NULL));

    int random_num = rand() % 62; 

    if (random_num < 26) {
        return 'A' + random_num;
    } else if (random_num < 52) {
        return 'a' + (random_num - 26);
    } else {
        return '0' + (random_num - 52);
    }
}

/**
 * @brief This function generates a random string of the given length.
 * @param length The length of the string to be generated.
 * @return char* The generated random string.
 */

char* generate_random_string(int length) {
    char* str = (char*)malloc((length + 1) * sizeof(char));
    //srand(time(0));
    for (int i = 0; i < length; i++) {
        str[i] = generate_random_char();
    }
    str[length] = '\0';
    return str;
}

/**
 * @brief This function creates an array of random Employees of the given length.
 * @param n The length of the Employee array to be created.
 * @return Employee** A pointer to the created Employee array.
 */

Employee* createRandomEmployee(){
    //srand(time(NULL));
  char* name = generate_random_string(5);
  int birth_year = rand()%100;
  int start_year = rand()%200;
  Employee* employee = make_employee(name,birth_year,start_year);
  free(name);
  return employee;
}

/**
 * @brief This function creates an array of random Employees of the given length.
 * @param n The length of the Employee array to be created.
 * @return Employee** A pointer to the created Employee array.
 */
Employee** createRandomEmployeeArray(int n){
  int i;
  int j;
  Employee** array = (Employee**) malloc(n*sizeof(Employee));
  for (i=0; i < n; ++i){
    
    array[i] = (Employee*) malloc(sizeof(Employee));
  }
  for (j=0; j < n; ++j){
    array[j] = createRandomEmployee();
  }
  return array;
}

/**
 * @brief This function prints the details of an array of Employees.
 * @param array The Employee array to be printed.
 * @param n The length of the Employee array.
 */

void printEmployeeArray(Employee** array, int n){
  int i;
  for (i=0; i < n; ++i){
    printf("Employee %d\n",i+1);
    print_employee(array[i]);
    printf("\n");
  }
}

/**
 * @brief This function creates a shallow copy of an Employee array.
 * @param array The Employee array to be copied.
 * @param n The length of the Employee array.
 * @return Employee** A pointer to the shallow copied Employee array.
 */

Employee** shallowCopy(Employee** array,int n){
  int i;
  Employee** newArray = (Employee**) malloc(n*sizeof(Employee));
  for (i = 0; i < n; ++i){
    newArray[i] = array[i];
  }
  return newArray;
}

/**
 * @brief This function creates a deep copy of an Employee array.
 * @param array The Employee array to be copied.
 * @param n The length of the Employee array.
 * @return Employee** A pointer to the deep copied Employee array.
 */

Employee** deepCopy(Employee** array, int n){
  int i;
  int j;
  Employee** newArray = (Employee**) malloc(n*sizeof(Employee));
  for (i=0; i < n; ++i){
    newArray[i] = (Employee*) malloc(sizeof(Employee));
    mystrcpy(newArray[i]->name, array[i]->name);
    newArray[i]->birth_year = array[i]->birth_year;
    newArray[i]->start_year = array[i]->start_year;
  }
  return newArray;
}

/**
 * @brief This function frees the memory occupied by an Employee array.
 * @param array The Employee array to be freed.
 * @param n The length of the Employee array.
 */

void freeArray(Employee** array, int n){

  int i;
  for (i=0; i < n; ++i){
    free(array[i]);
  }
  free(array);

}