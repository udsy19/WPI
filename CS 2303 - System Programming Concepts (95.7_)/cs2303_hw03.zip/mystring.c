/**
 * 
 * @file mystring.c
 * @author Udaya Vijay Anand
 * 
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "mystring.h"

/**
 * @brief Duplicates a string
 *
 * The function allocates memory for a copy of the string and returns a pointer to it.
 *
 * @param src Pointer to the source string to be duplicated
 * @return Pointer to the duplicated string or NULL if the memory allocation fails
 */

char* mystrdup(const char* src) {
  int length; 	
  char* newstr;

  length = strlen(src) + 1;  	
  newstr = (char*) malloc(length); 	

  if (newstr == 0) {
	return (char *) 0;
  }

  strcpy(newstr, src);
  return newstr;
  printf("mystrdup: %s\n", newstr);
}

/**
 * @brief Calculates the length of a string
 *
 * The function calculates the length of the string, excluding the terminating null character.
 *
 * @param str Pointer to the string
 * @return Length of the string
 */

size_t mystrlen(const char* str){
  int i = 0;
  while(*str != '\0'){
    ++i;
    *str++;
  }
  return i;
}

/**
 * @brief Copies a string
 *
 * The function copies the source string to the destination string and returns a pointer to the destination string.
 *
 * @param a Pointer to the destination string
 * @param b Pointer to the source string
 * @return Pointer to the destination string
 */

char* mystrcpy(char* a, char*b) {
  int i;
  for(i=0; *b!='\0'; i++) {
    *a=*b;

    a++;
    b++;
  }

  return a;
}

/**
 * @brief Concatenates two strings
 *
 * The function concatenates the source string to the end of the destination string and returns a pointer to the destination string.
 *
 * @param destination Pointer to the destination string
 * @param source Pointer to the source string
 * @return Pointer to the destination string
 */

char *mystrcat(char *destination, const char *source) {
    char *ptr = destination + strlen(destination);
    while (*source != '\0') {
        *ptr++ = *source++;
    }
    *ptr = '\0';
    return destination;
}

/**
 * @brief Concatenates two strings with a specified limit
 *
 * The function concatenates at most n characters from the source string to the end of the destination string and returns a pointer to the destination string.
 *
 * @param destination Pointer to the destination string
 * @param source Pointer to the source string
 * @param n Maximum number of characters to be concatenated from the source string
 * @return Pointer to the destination string
 */

char *mystrncat(char *destination, const char *source, size_t n) {
    char *ptr = destination + strlen(destination);
    size_t i;
    for (i = 0; i < n && *source != '\0'; i++) {
        *ptr++ = *source++;
    }
    *ptr = '\0';
    return destination;
}

/**
 * @brief Copies a string with a specified limit
 *
 * The function copies at most n characters from the source string to the destination string and returns a pointer to the destination string.
 *
 * @param dest Pointer to the destination string
 * @param src Pointer to the source string
 * @param n Maximum number of characters to be copied from the source string
 * @return Pointer to the destination string
 */

char *mystrncpy(char *dest, const char *src, size_t n) {
    size_t i;
    for (i = 0; i < n && src[i] != '\0'; i++) {
        dest[i] = src[i];
    }
    for ( ; i < n; i++) {
        dest[i] = '\0';
    }
    return dest;
}

/**
 * @brief Duplicates a string with a specified limit
 *
 * The function allocates memory for a copy of the source string with a maximum length of n characters and returns a pointer to it.
 *
 * @param src Pointer to the source string to be duplicated
 * @param n Maximum length of the duplicated string
 * @return Pointer to the duplicated string or NULL if the memory allocation fails
 */

char *mystrndup(const char *src, size_t n) {
    size_t len = strnlen(src, n);
    char *dest = malloc(len + 1);
    if (dest == NULL) {
        return NULL;
    }
    dest[len] = '\0';
    return mystrncpy(dest, src, len);
}