/**
 * @file mystruct.h
 * @brief This file contains the declarations of the functions that perform operations on Employees.
 */

#ifndef STRUCT_H
#define STRUCT_H
#define MAX_NAME_LENGTH 100 // Maximum length of a name string in the example struct

typedef struct {
  char name[MAX_NAME_LENGTH];
  int birth_year;
  int start_year;
} Employee;

/*!
 * \brief Creates an Employee structure with the given name, birth year, and start year
 *
 * \param[in] name The name of the employee
 * \param[in] birth_year The birth year of the employee
 * \param[in] start_year The year the employee started working
 *
 * \return A pointer to the newly created Employee structure
 */

Employee* make_employee(char* name, int birth_year, int start_year);

/*!
 * \brief Prints the details of an Employee structure
 *
 * \param[in] emp The pointer to the Employee structure to print
 */

void print_employee(Employee* emp);

/*!
 * \brief Generates a random character
 *
 * \return The generated random character
 */

char generate_random_char();

/*!
 * \brief Generates a random string of the given length
 *
 * \param[in] length The length of the string to generate
 *
 * \return A pointer to the generated random string
 */

char* generate_random_string(int length);

/*!
 * \brief Generates a random string of the given length
 *
 * \param[in] length The length of the string to generate
 *
 * \return A pointer to the generated random string
 */

Employee* createRandomEmployee();

/*!
 * \brief Creates a random Employee structure
 *
 * \return A pointer to the newly created random Employee structure
 */

Employee** createRandomEmployeeArray(int n);

/*!
 * \brief Prints the details of an array of Employee structures
 *
 * \param[in] array The pointer to the array of Employee structures to print
 * \param[in] n The number of Employee structures in the array
 */

void printEmployeeArray(Employee** array, int n);

/*!
 * \brief Creates a shallow copy of an array of Employee structures
 *
 * \param[in] array The pointer to the array of Employee structures to copy
 * \param[in] n The number of Employee structures in the array
 *
 * \return A pointer to the newly created shallow copy of the array of Employee structures
 */

Employee** shallowCopy(Employee** array,int n);

/*!
 * \brief Creates a deep copy of an array of Employee structures
 *
 * \param[in] array The pointer to the array of Employee structures to copy
 * \param[in] n The number of Employee structures in the array
 *
 * \return A pointer to the newly created deep copy of the array of Employee structures
 */

Employee** deepCopy(Employee** array, int n);

/*!
 * \brief Frees an array of Employee structures
 *
 * \param[in] array The pointer to the array of Employee structures to free
 * \param[in] n The number of Employee structures in the array
 */

void freeArray(Employee** array, int n);

#endif